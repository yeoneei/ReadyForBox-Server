const mariadb = require('mariadb');

const pool = mariadb.createPool({
    host: 'readyforbox.cvrjbenzccpt.ap-northeast-2.rds.amazonaws.com', 
    port: 3306,
    user: 'getreadysetgo', 
    password: 'thstndud12',
    database: 'readyforbox',
});


module.exports = pool;